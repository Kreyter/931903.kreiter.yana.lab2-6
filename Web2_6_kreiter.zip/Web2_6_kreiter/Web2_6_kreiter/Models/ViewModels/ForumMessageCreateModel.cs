﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web2_6_kreiter.Models.ViewModels
{
    public class ForumMessageCreateModel
    {
        public String Text { get; set; }
    }
}
