﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web2_6_kreiter.Models
{
    public class FolderViewModel
    {
        public String Name { get; set; }
        public Guid? FolderId { get; set; }
    }
}
