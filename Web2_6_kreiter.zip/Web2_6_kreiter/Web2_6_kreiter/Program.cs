using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

namespace Web2_6_kreiter
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Program.BuildWebHost(args).MigrateDatabase().Run();
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .Build();
    }
}