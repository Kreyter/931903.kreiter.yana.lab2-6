﻿using System;
using Web2_6_kreiter.Models;

namespace Web2_6_kreiter.Services
{
    public interface IUserPermissionsService
    {
        Boolean CanEditPost(Post post);

        Boolean CanEditPostComment(PostComment postComment);
    }
}